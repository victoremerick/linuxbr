from pathlib import Path
import subprocess,json,os
root=Path('/mnt/qa09-installed');qa=Path('/home/user/qa09');mounts=[];policy=root/'usr/sbin/policy-rc.d';assert not policy.exists();resolv=root/'etc/resolv.conf';link=os.readlink(resolv) if resolv.is_symlink() else None;old=resolv.read_bytes() if resolv.exists() else None
try:
 policy.write_text('#!/bin/sh\nexit 101\n');policy.chmod(0o755)
 if resolv.is_symlink():resolv.unlink()
 resolv.write_bytes(Path('/etc/resolv.conf').read_bytes())
 for name in ['dev','proc','sys']:
  subprocess.run(['mount','--rbind','/'+name,str(root/name)],check=True);subprocess.run(['mount','--make-rslave',str(root/name)],check=True);mounts.append(root/name)
 with (qa/'installed-ssh16.log').open('w') as log:
  r=subprocess.run(['chroot',str(root),'apt-get','-y','install','openssh-server'],env=dict(os.environ,DEBIAN_FRONTEND='noninteractive'),stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0
 key=Path('/home/user/.ssh/authorized_keys').read_bytes();assert key.startswith(b'ssh-ed25519 ')
 home=root/'home/brasil/.ssh';home.mkdir(mode=0o700,exist_ok=True);os.chown(home,1000,1000);p=home/'authorized_keys';p.write_bytes(key);p.chmod(0o600);os.chown(p,1000,1000)
 (qa/'installed-ssh16-result.json').write_text(json.dumps(dict(status='PASS',ssh_test_dependency_installed=True),indent=2))
finally:
 for path in reversed(mounts):subprocess.run(['umount','-R',str(path)],check=True)
 policy.unlink(missing_ok=True);resolv.unlink(missing_ok=True)
 if link:resolv.symlink_to(link)
 elif old is not None:resolv.write_bytes(old)
 subprocess.run(['sync'])
 subprocess.run(['umount',str(root)],check=True)
