#!/bin/sh
python3 /home/user/qa09/quick-native-wrapper.py > /home/user/qa09/quick-native-wrapper.log 2>&1
