from pathlib import Path
import json
import os
import subprocess
import time

base=Path('/home/user/qa09')
result={}
def command(*args):
    return subprocess.check_output(args,text=True,timeout=10).strip()

previous=command('pactl','get-default-sink')
module=None
stream=None
try:
    module=command('pactl','load-module','module-null-sink','sink_name=linuxbr_qa09_null','sink_properties=device.description=LinuxBR-QA09')
    assert module.isdigit()
    command('pactl','set-default-sink','linuxbr_qa09_null')
    stream=subprocess.Popen(['paplay','--device=linuxbr_qa09_null','--raw','--format=s16le','--rate=44100','--channels=2','/dev/zero'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    time.sleep(.5)
    assert stream.poll() is None
    env={**os.environ,'LINUXBR_DISPOSABLE_VM':'1','QT_QPA_PLATFORM':'offscreen','QT_QUICK_BACKEND':'software'}
    test=subprocess.run(['python3',str(base/'source16/tests/test-quick-controls-native.py')],env=env,capture_output=True,text=True,timeout=70)
    (base/'quick-native-validation.log').write_text(test.stdout+test.stderr)
    result={'returncode':test.returncode,'output':test.stdout,'context':'active graphical session, virtual Wi-Fi/BT, active null audio sink'}
    if test.returncode:result['error']=test.stderr[-1800:]
finally:
    if stream is not None:
        stream.terminate()
        stream.wait(timeout=5)
    if module is not None:
        subprocess.run(['pactl','unload-module',module],capture_output=True)
        time.sleep(.5)
        subprocess.run(['pactl','set-default-sink',previous],capture_output=True)
    (base/'quick-native-validation.json').write_text(json.dumps(result,indent=2))
