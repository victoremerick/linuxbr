import os,dbus
from dbus.mainloop.glib import DBusGMainLoop
from gi.repository import GLib
os.environ['DBUS_SESSION_BUS_ADDRESS']='unix:path=/run/user/'+str(os.getuid())+'/bus'
DBusGMainLoop(set_as_default=True)
bus=dbus.SessionBus();proxy=dbus.Interface(bus.get_object('org.freedesktop.ScreenSaver','/ScreenSaver'),'org.freedesktop.ScreenSaver')
cookie=proxy.Inhibit('Linux BR','Validação da sessão em andamento')
print('session idle inhibition active',flush=True)
GLib.MainLoop().run()
