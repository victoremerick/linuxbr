from pathlib import Path
import subprocess,os,json,time,tempfile
root=Path('/home/user/qa09/source16');out=Path('/home/user/qa09/regressions16');out.mkdir(exist_ok=True)
excluded={'test-packages.py':'Requires generated package workspace','test-quick-controls-native.py':'Requires virtual radios and an active audio stream'}
results=[]
for script in sorted((root/'tests').glob('test-*.py')):
 if script.name in excluded:
  results.append(dict(test=script.name,status='SEPARATE',reason=excluded[script.name]));continue
 with tempfile.TemporaryDirectory(prefix='linuxbr-regression-') as temporary:
  work=Path(temporary)
  for directory in ['data','config','cache']:(work/directory).mkdir()
  env={**os.environ,'QT_QPA_PLATFORM':'offscreen','QT_QUICK_BACKEND':'software','XDG_DATA_HOME':str(work/'data'),'XDG_CONFIG_HOME':str(work/'config'),'XDG_CACHE_HOME':str(work/'cache')}
  start=time.monotonic()
  try:
   p=subprocess.run(['python3',str(script)],env=env,cwd=root,capture_output=True,text=True,timeout=80)
   text=p.stdout+p.stderr;code=p.returncode
  except subprocess.TimeoutExpired as error:text=str(error);code=124
  (out/(script.name+'.log')).write_text(text)
  results.append(dict(test=script.name,status='PASS' if code==0 else 'FAIL',exit_code=code,seconds=round(time.monotonic()-start,2)))
  (out/'results.json').write_text(json.dumps(results,indent=2))
(out/'complete').write_text('done\n')
print(json.dumps(dict(total=len(results),passed=sum(r['status']=='PASS' for r in results),failed=[r['test'] for r in results if r['status']=='FAIL'])))

