import dbus,time
bus=dbus.SessionBus()
try:
 proxy=bus.get_object('org.freedesktop.ScreenSaver','/ScreenSaver');cookie=dbus.Interface(proxy,'org.freedesktop.ScreenSaver').Inhibit('Linux BR validation','Instalação em andamento')
except dbus.DBusException:cookie=None
while True:time.sleep(30)
